-- SunShift account storage. Run this once in Supabase SQL Editor.
-- Every row is protected by its owner's authenticated user id.
create table if not exists public.home_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  settings jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.appliance_schedule (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (length(name) between 1 and 100),
  time text not null check (time ~ '^(0?[1-9]|1[0-2]):[0-5][0-9] (AM|PM)$'),
  kwh numeric(8,2) not null check (kwh > 0 and kwh <= 1000),
  date date not null default current_date,
  created_at timestamptz not null default now()
);
create index if not exists appliance_schedule_user_date_idx on public.appliance_schedule(user_id, date, created_at);

create table if not exists public.energy_runs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  record jsonb not null,
  created_at timestamptz not null default now()
);
create index if not exists energy_runs_user_created_idx on public.energy_runs(user_id, created_at desc);

alter table public.home_settings enable row level security;
alter table public.appliance_schedule enable row level security;
alter table public.energy_runs enable row level security;

drop policy if exists "Users manage their own home settings" on public.home_settings;
create policy "Users manage their own home settings" on public.home_settings
  for all to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

drop policy if exists "Users manage their own appliance schedule" on public.appliance_schedule;
create policy "Users manage their own appliance schedule" on public.appliance_schedule
  for all to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

drop policy if exists "Users manage their own energy runs" on public.energy_runs;
create policy "Users manage their own energy runs" on public.energy_runs
  for all to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

grant select, insert, update, delete on public.home_settings, public.appliance_schedule, public.energy_runs to authenticated;
